# Data Structures
### Implementation of Data Structure in C++ Programming Language (Started as a beginner)  
## Directories Description
### 1. [Basic C++](https://github.com/Nitesh-Singh-5/Placement-Preparation/tree/master/coding-prep/Basic%20C%2B%2B)
### 2. [Recursion](https://github.com/Nitesh-Singh-5/Placement-Preparation/tree/master/coding-prep/DSA/1.%20Recursion)
### 3. [Arrays](https://github.com/Nitesh-Singh-5/Placement-Preparation/tree/master/coding-prep/DSA/2.%20Arrays)
### 4. [String](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/3.%20String)
### 5. [Matrices](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/4.%20Matrices)
### 6. [Linked List](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/5.%20Linked%20List)
### 7. [Stack](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/6.%20Stack)
### 8. [Queue](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/7.%20Queue)
### 9. [Binary Tree](https://github.com/Nitesh-Singh-5/DSA/tree/master/coding-prep/DSA/8.%20Binary%20Tree)
